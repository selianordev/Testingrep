//jquery-ui tooltip

 $('#contactName').on('input',function(){
    var input =$(this);
    var is_name=input.val();
    if(is_name){ input.removeClass('invalid').addClass('valid');}
    else{
        input.removeClass('valid').addClass('invalid');
    }
});
// second fields start here
    $('#email').on('input',function(){
        var input = $(this);
        var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        var is_email = re.test(input.val());
        if(is_email){
            input.removeClass('invalid').addClass('valid');
        }else{
            input.removeClass('valid').addClass('invalid');
        }
    });
    
    //validate phone number
    $('#phone').on('input',function(){
        var input= $(this);
        var is_phone= input.isNumber();
        if(is_phone){
            input.removeClass('invalid').addClass('valid');
        }else{
            input.removeClass('valid').addClass('invalid');
        }
    });
    
    //message textarea goes here
    
    $('#msg').keyup(function(event){
        var input = $(this);
        var message = $(this).val();
        console.log(message);
        if(message){
            textarea.removeClass('invalid').addClass('valid');
        }
        else{
            textarea.removeClass('valid').addClass('invalid');
        }
    });
    
    //submit button operation start here
    $('#submitbutton, submit').click(function(event){
        var form_data =$('#contact_form').serializeArray();
        var error_free= true;
        for(var input in form_data){
            var element = $('#contactNane_'+form_data[input][name]);
            var valid = element.hasClass('valid');
            var error_element = $('span',element.parent());
            if(!valid){error_element.removeClass('error').addClass('show_error');}
            else{
                element.removeClass('show_error').addClass('error');
            }
            if(!error_free){
                event.preventDefault();
                
            }
            else{
             swal("Well done!", "Your Message has been Sent and will get back to you soon!", "success");
            }
        }
    });
                   


// Show or hide the sticky footer button
$(window).scroll(function() {
	if ($(this).scrollTop() > 200) 
		{
			$('#back-to-top').fadeIn(200);
		} else {
			$('#back-to-top').fadeOut(200);
	}
});
// Animate the scroll to top when the stick footer button is clicked
$('#back-to-top').click(function(event) {
	event.preventDefault();
	$('html, body').animate({scrollTop: 0}, 600);
})
// Animate the scroll bar to contacts section
$('a[href^="#contact"]').on('click', function(event){
	var target = $($(this).attr('href'));
	if(target.length) {
	event.preventDefault();
	$('html, body').animate({
	scrollTop: target.offset().top - 75}, 1000, function(){});
  }
}) // end on

// Animate the scroll bar to home section
$('a[href^="#home"]').on('click', function(event){
	var target = $($(this).attr('href'));
	if(target.length) {
	event.preventDefault();
	$('html, body').animate({
	scrollTop: target.offset().top}, 1000);
  }
}) // end on
// Animate the scroll bar to About services
$('a[href^="#about"]').on('click', function(event){
	var target = $($(this).attr('href'));
	if(target.length) {
	event.preventDefault();
	$('html, body').animate({
	scrollTop: target.offset().top - 75}, 1000, function(){});
  }
}) // end on
// Animate the scroll bar to services section
$('a[href^="#services"]').on('click', function(event){
	var target = $($(this).attr('href'));
	if(target.length) {
	event.preventDefault();
	$('html, body').animate({
	scrollTop: target.offset().top - 75}, 1000, function(){});
  }
}) // end on
// Animate the scroll bar to services section
$('a[href^="#team"]').on('click', function(event){
	var target = $($(this).attr('href'));
	if(target.length) {
	event.preventDefault();
	$('html, body').animate({
	scrollTop: target.offset().top - 75}, 1000, function(){});
  }
}) // end on
// Animate the scroll bar to services section
$('a[href^="#gallary"]').on('click', function(event){
	var target = $($(this).attr('href'));
	if(target.length) {
	event.preventDefault();
	$('html, body').animate({
	scrollTop: target.offset().top - 75}, 1000, function(){});
  }
}) // end on
	
	
	